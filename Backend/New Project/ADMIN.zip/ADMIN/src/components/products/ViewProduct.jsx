import React from 'react'

export default function ViewProduct() {
  return (
    <>
    
    </>
  )
}
