import React from 'react'
import Cart from '../Components/Page/Cart'

export default function page() {
  return (
    <>
     <Cart/>

    </>
   
  )
}
