import React from 'react'
import Productlisting from '../Components/Products/Productlisting'

export default function page() {
  return (
 <>
  <Productlisting/>
 </>
  )
}
